# Proyecto 3: Biblioteca Triple Peaks

La página web de la Biblioteca Triple Peaks es el tercer proyecto en el programa de Desarrollo web de TripleTen. Fue creado utilizando HTML y CSS, con base en un brief de diseño.

## Características del proyecto

- HTML5 semántico
- Flexbox
- Posicionamiento
